package cn.com.yusys.yusp.admin.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.github.pagehelper.PageHelper;

import cn.com.yusys.yusp.admin.domain.SModifyTrace;
import cn.com.yusys.yusp.admin.repository.mapper.SModifyTraceMapper;
import cn.com.yusys.yusp.commons.mapper.QueryModel;

/**
 * 
 * @项目名称:ncmis-cunstomer-manager-core
 * @类名称:SModifyTraceService
 * @类描述:#小U留痕服务类
 * @功能描述:
 * @创建人:liuxin8@yusys.com.cn
 * @创建时间:2018-09-25 15:53
 * @修改备注:
 * @修改日期		修改人员		修改原因
 * --------    --------		----------------------------------------
 * @version 1.0.0
 * @Copyright (c) 2018宇信科技-版权所有
 */
@Service
public class SModifyTraceService {

    @Autowired
    private SModifyTraceMapper sModifyTraceMapper;

    /**
     * 
     * @方法名称:selectSModifyTraceByPk
     * @方法描述:根据条件查询所有修改记录
     * @参数与返回说明:
     * @算法描述:
     */
    public List<SModifyTrace> selectSModifyTraceByPk(QueryModel model) {
        List<SModifyTrace> list = sModifyTraceMapper.selectSModifyTraceByPk(model);
        return list;
    }

    /**
     * 
     * @方法名称:selectSMTraceWithPage
     * @方法描述:根据条件查询所有修改记录（分页）
     * @参数与返回说明:
     * @算法描述:
     */
    public List<SModifyTrace> selectSMTraceWithPage(QueryModel model) {
        PageHelper.startPage(model.getPage(), model.getSize());
        List<SModifyTrace> list = sModifyTraceMapper.selectSModifyTraceByPk(model);
        PageHelper.clearPage();
        return list;
    }

    /**
     * 
     * @方法名称:addSModifyTrace
     * @方法描述:新增修改痕迹
     * @参数与返回说明:
     * @算法描述:
     */
    public Boolean addSModifyTrace(SModifyTrace sModifyTrace) {
        int i = sModifyTraceMapper.insertSelective(sModifyTrace);
        return i > 0;
    }

    /**
     * 
     * @方法名称:insertBatchSModifyTrace
     * @方法描述:批量新增修改痕迹
     * @参数与返回说明:
     * @算法描述:
     */
    public int insertBatchSModifyTrace(List<SModifyTrace> list) {
        int result = sModifyTraceMapper.insertBatchSModifyTrace(list);
        return result;
    }

}
