package cn.com.yusys.yusp.admin.web.rest;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import cn.com.yusys.yusp.admin.domain.SModifyTrace;
import cn.com.yusys.yusp.admin.service.SModifyTraceService;
import cn.com.yusys.yusp.commons.mapper.QueryModel;
import cn.com.yusys.yusp.commons.web.rest.dto.ResultDto;

/**
 * 
 * @项目名称:ncmis-cunstomer-manager-core
 * @类名称:SModifyTraceResource
 * @类描述:#小U留痕资源类
 * @功能描述:
 * @创建人:liuxin8@yusys.com.cn
 * @创建时间:2018-09-25 15:55
 * @修改备注:
 * @修改日期		修改人员		修改原因
 * --------    --------		----------------------------------------
 * @version 1.0.0
 * @Copyright (c) 2018宇信科技-版权所有
 */
@RestController
@RequestMapping("/api/utrace")
public class SModifyTraceResource {

    @Autowired
    private SModifyTraceService sModifyTraceService;

    /**
    * 
    * @方法名称:selectSModifyTraceWithPage
    * @方法描述:展示修改痕迹历史信息(分页)
    * @参数与返回说明:
    * @算法描述:
    */
    @GetMapping("/selectSModifyTraceWithPage")
    public ResultDto<List<SModifyTrace>> selectSModifyTraceWithPage(QueryModel model) {
        List<SModifyTrace> list = sModifyTraceService.selectSMTraceWithPage(model);
        return new ResultDto<List<SModifyTrace>>(list);
    }

    /**
     * 
     * @方法名称:selectSModifyTrace
     * @方法描述:查询所有修改痕迹
     * @参数与返回说明:
     * @算法描述:
     */
    @GetMapping("/selectSModifyTrace")
    public ResultDto<List<SModifyTrace>> selectSModifyTrace(QueryModel model) {
        List<SModifyTrace> list = sModifyTraceService.selectSModifyTraceByPk(model);
        return new ResultDto<List<SModifyTrace>>(list);
    }

    /**
     * 
     * @方法名称:addSModifyTraceForBatch
     * @方法描述:新增修改记录
     * @参数与返回说明:
     * @算法描述:
     */
    @PostMapping("/addSModifyTrace")
    public ResultDto<Object> addSModifyTraceForBatch(@RequestBody ArrayList<SModifyTrace> t) {
        List<SModifyTrace> list = t;
        QueryModel model = new QueryModel();
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        if (list != null) {
            for (int i = 0; i < list.size(); i++) {
                SModifyTrace temp = list.get(i);
                temp.setmDatetime(df.format(new Date()));
                String strlstNewVal = null;
                // 检查此次修改的记录是否与最后一次修改的相同，如果相同则不予保存begin
                String strNewVal = temp.getmNewV() == null ? "" : temp.getmNewV();
                String strOldVal = temp.getmOldV() == null ? "" : temp.getmOldV();
                model.getCondition().put("mFieldId", temp.getmFieldId());
                List<String> mPkV = new ArrayList<String>();
                mPkV.add(temp.getmPkV());
                model.getCondition().put("mPkV", mPkV);
                List<SModifyTrace> list1 = new ArrayList<SModifyTrace>();
                list1 = sModifyTraceService.selectSModifyTraceByPk(model);
                SModifyTrace sModifyTrace = null;
                if (list1 != null && list1.size() > 0) {
                    sModifyTrace = sModifyTraceService.selectSModifyTraceByPk(model).get(0);
                }
                if (sModifyTrace != null) {
                    strlstNewVal = sModifyTrace.getmNewV() == null ? "" : sModifyTrace.getmNewV();
                } else {
                    // 如果是第一次增加 不保存（判断方法：没有上一条记录并且老数据为空）
                    if (strOldVal == null || "null".equals(strOldVal) || "".equals(strOldVal.trim())) {
                        continue;// 跳过
                    }
                }
                if (!strOldVal.equals(strNewVal) && !strNewVal.equals(strlstNewVal)) {
                    // 检查此次修改的记录是否与最后一次修改的相同，如果相同则不予保存end
                    sModifyTraceService.addSModifyTrace(temp);
                }

            }
        }
        return new ResultDto<Object>();
    }
}
