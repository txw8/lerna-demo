package cn.com.yusys.yusp.admin.repository.mapper;

import java.util.List;

import cn.com.yusys.yusp.admin.domain.SModifyTrace;
import cn.com.yusys.yusp.commons.mapper.CommonMapper;
import cn.com.yusys.yusp.commons.mapper.QueryModel;

/**
 * 
 * @项目名称:ncmis-cunstomer-manager-core
 * @类名称:SModifyTraceMapper
 * @类描述:#小U留痕Dao类
 * @功能描述:
 * @创建人:liuxin8@yusys.com.cn
 * @创建时间:2018-09-25 15:33
 * @修改备注:
 * @修改日期		修改人员		修改原因
 * --------    --------		----------------------------------------
 * @version 1.0.0
 * @Copyright (c) 2018宇信科技-版权所有
 */
public interface SModifyTraceMapper extends CommonMapper<SModifyTrace> {

    List<SModifyTrace> selectSModifyTraceByPk(QueryModel model);

    int insertBatchSModifyTrace(List<SModifyTrace> list);
}