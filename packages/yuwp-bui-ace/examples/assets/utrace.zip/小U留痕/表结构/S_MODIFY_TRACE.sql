﻿create table S_MODIFY_TRACE
(
  seqid        VARCHAR2(32) not null,
  usr_id       VARCHAR2(20),
  m_menu_id    VARCHAR2(32),
  m_pk_v       VARCHAR2(250),
  org_id       VARCHAR2(20),
  m_field_id   VARCHAR2(50),
  m_field_nm   VARCHAR2(50),
  m_old_v      VARCHAR2(1000),
  m_old_disp_v VARCHAR2(1000),
  m_new_v      VARCHAR2(1000),
  m_new_disp_v VARCHAR2(1000),
  m_datetime   VARCHAR2(20)
)
;
comment on table S_MODIFY_TRACE
  is '表单字段值修改记录表';
comment on column S_MODIFY_TRACE.seqid
  is '主键';
comment on column S_MODIFY_TRACE.usr_id
  is '操作用户';
comment on column S_MODIFY_TRACE.m_menu_id
  is '菜单ID';
comment on column S_MODIFY_TRACE.m_pk_v
  is '数据主键';
comment on column S_MODIFY_TRACE.org_id
  is '机构ID';
comment on column S_MODIFY_TRACE.m_field_id
  is '表单字段ID';
comment on column S_MODIFY_TRACE.m_field_nm
  is '表单字段名称';
comment on column S_MODIFY_TRACE.m_old_v
  is '字段原值';
comment on column S_MODIFY_TRACE.m_old_disp_v
  is '字段原值描述';
comment on column S_MODIFY_TRACE.m_new_v
  is '字段新值';
comment on column S_MODIFY_TRACE.m_new_disp_v
  is '字段新值描述';
comment on column S_MODIFY_TRACE.m_datetime
  is '记录时间';
alter table S_MODIFY_TRACE
  add constraint PK_S_MODIFY_TRACE primary key (SEQID);